"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.routes = void 0;
const aws_http_api_backend_1 = require("@ezapi/aws-http-api-backend");
const json_middleware_1 = require("@ezapi/json-middleware");
const router_core_1 = require("@ezapi/router-core");
exports.routes = router_core_1.RouteBuilder.withMiddleware((0, json_middleware_1.JsonParserMiddlerware)())
    .route("GET", "/hello/{name}")
    .handle(async (r) => (0, router_core_1.Ok)({ message: `Hello ${r.pathParams.name}` }))
    .build();
exports.handler = (0, aws_http_api_backend_1.httpApiHandler)(exports.routes, "live");
