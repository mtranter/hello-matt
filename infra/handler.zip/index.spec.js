"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("./index");
describe("hello world", () => {
    it("should return hello world", async () => {
        const result = await (0, index_1.handler)({
            requestContext: {
                http: {
                    method: "GET",
                    path: "/hello/world",
                },
            },
            headers: {
                "content-type": "application/json",
            },
        }, {}, () => { });
        expect(result.statusCode).toEqual(200);
        expect(result.body).toEqual(JSON.stringify({ message: "Hello world" }));
    });
});
